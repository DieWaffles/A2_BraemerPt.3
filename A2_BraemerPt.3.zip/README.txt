Andrew Braemer. m240576
All parts completed
Will show working with phone in class